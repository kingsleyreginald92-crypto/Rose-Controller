# Rose Controller — Prototype 0.3

This prototype connects the core local control loop:

**Observe → Plan → Explain → Wait for approval → Revalidate → Execute → Observe again**

## What changed in 0.3
- `ScreenObserverService` produces a structured `ScreenSnapshot` containing visible labels, content descriptions, clickability, enabled state, class name, and screen bounds.
- Snapshot IDs are stable for the same observed UI structure instead of changing on every accessibility event.
- `ActionPlanner` can find a clickable control by exact visible label/content description and create an `ActionRequest` tied to that snapshot.
- `PermissionGate` stores one pending action and rejects approval if the screen has changed.
- `ActionController` refuses unapproved actions and executes only the approved request.
- The demo now performs a real tap after approval when a clickable `Settings` control is found.

## Test flow
1. Build and install the app.
2. Open **Open Accessibility Settings** and explicitly enable **Rose Screen Observer**.
3. Return to the app and tap **Refresh Screen**.
4. Navigate to a screen containing a clickable control labeled `Settings`.
5. Tap **Ask Rose to Tap Settings**.
6. Read the exact proposed action.
7. Tap **APPROVE THIS ACTION**. The app re-checks the screen snapshot before executing the tap.
8. Tap **DENY** instead to verify that no action is performed.

## Important limitation
This is still a local Android prototype. It does not yet connect a conversational AI/voice service. It also intentionally does not implement typing, swiping, purchases, form submission, messaging, or other consequential actions yet.

Android AccessibilityService is a privileged user-enabled mechanism and apps using it must follow Android's accessibility requirements and applicable distribution policies. It should not be treated as unrestricted automation.


## Prototype 0.4
Adds a real notification-based one-action approval path. When an action is proposed, Rose Controller posts an approval notification with separate APPROVE and DENY actions. Approval is valid only for the exact pending request and only while the observed screen state is unchanged.

On Android 13+, allow notifications when prompted so approval requests can appear while another app is in the foreground.
