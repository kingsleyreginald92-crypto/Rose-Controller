package com.rose.controller

object PermissionGate {
    private var pending: ActionRequest? = null

    fun propose(request: ActionRequest) {
        require(request.status == ApprovalStatus.PENDING)
        pending = request
    }

    fun pending(): ActionRequest? = pending

    fun approve(currentSnapshot: ScreenSnapshot): ActionRequest {
        val request = requireNotNull(pending) { "No pending action." }
        require(request.status == ApprovalStatus.PENDING) { "Action is no longer pending." }
        require(request.screenStateId == currentSnapshot.id) {
            "Screen changed. New approval required."
        }
        request.status = ApprovalStatus.APPROVED
        pending = null
        return request
    }

    fun deny() {
        pending?.status = ApprovalStatus.DENIED
        pending = null
    }
}
