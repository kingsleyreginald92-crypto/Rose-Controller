package com.rose.controller

import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.content.pm.PackageManager
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var statusText: TextView
    private lateinit var actionText: TextView
    private lateinit var controlsText: TextView
    private lateinit var instructionInput: EditText
    private var demoRequest: ActionRequest? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ApprovalNotifier.ensureChannel(this)
        requestNotificationPermission()
        showMainScreen()
    }

    private fun showMainScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 50, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Rose Controller 0.6"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "Observe → Understand → Propose → YES/NO → Execute"
            textSize = 16f
            setPadding(0, 20, 0, 12)
        }
        controlsText = TextView(this).apply {
            text = "No screen observed yet."
            textSize = 15f
            setPadding(0, 8, 0, 16)
        }
        actionText = TextView(this).apply {
            text = "No pending action."
            textSize = 18f
            setPadding(0, 8, 0, 20)
        }

        instructionInput = EditText(this).apply {
            hint = "Tell Rose what to tap (example: Open Settings)"
            textSize = 16f
            singleLine = true
        }

        val scan = Button(this).apply {
            text = "SEE CURRENT SCREEN"
            setOnClickListener { refreshScreen() }
        }
        val propose = Button(this).apply {
            text = "PROPOSE MY REQUEST"
            setOnClickListener { proposeTapFromInstruction() }
        }
        val approve = Button(this).apply {
            text = "YES — APPROVE"
            setOnClickListener { approveAndExecute() }
        }
        val deny = Button(this).apply {
            text = "NO — DENY"
            setOnClickListener { denyAction() }
        }
        val accessibility = Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(instructionInput)
        root.addView(controlsText)
        root.addView(actionText)
        root.addView(scan)
        root.addView(propose)
        root.addView(approve)
        root.addView(deny)
        root.addView(accessibility)
        setContentView(root)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    private fun refreshScreen() {
        val service = ScreenObserverService.instance
        if (service == null) {
            statusText.text = "Accessibility service is not enabled."
            controlsText.text = "Enable Rose Screen Observer first."
            return
        }
        val snapshot = service.refreshSnapshot()
        statusText.text = "SCREEN UNDERSTOOD — ${snapshot.nodes.size} labeled controls/text items"
        controlsText.text = formatControls(snapshot)
    }

    private fun formatControls(snapshot: ScreenSnapshot): String {
        val clickable = snapshot.nodes.filter { it.enabled && it.clickable }
        if (clickable.isEmpty()) return "No enabled clickable controls were detected."
        return buildString {
            append("Clickable controls Rose can recognize:\n")
            clickable.take(25).forEachIndexed { index, node ->
                val label = node.text ?: node.contentDescription ?: "(unlabeled)"
                append("${index + 1}. $label\n")
            }
            if (clickable.size > 25) append("…and ${clickable.size - 25} more")
        }
    }

    private fun proposeTapFromInstruction() {
        val service = ScreenObserverService.instance
        if (service == null) {
            statusText.text = "Enable Rose Screen Observer first."
            return
        }

        val instruction = instructionInput.text.toString().trim()
        if (instruction.isBlank()) {
            statusText.text = "Tell Rose what you want her to tap first."
            return
        }

        val snapshot = service.refreshSnapshot()
        val request = ActionPlanner.proposeTapFromInstruction(instruction, snapshot)
        if (request == null) {
            statusText.text = "I cannot match that request to a clickable control on this screen."
            actionText.text = "No action proposed. Nothing was executed."
            return
        }

        demoRequest = request
        PermissionGate.propose(request)
        ApprovalNotifier.show(this, request)
        statusText.text = "REQUEST UNDERSTOOD — WAITING FOR YOUR YES / NO"
        actionText.text = "ROSE WANTS TO:\n\n${request.explanation}\n\nYES approves only this one action."
    }

    private fun approveAndExecute() {
        val service = ScreenObserverService.instance
        if (service == null || demoRequest == null) {
            statusText.text = "Nothing is waiting for approval."
            return
        }
        try {
            val snapshot = service.refreshSnapshot()
            val approved = PermissionGate.approve(snapshot)
            val executed = ActionController(service).execute(approved, snapshot)
            statusText.text = if (executed) "EXECUTED: ${approved.explanation}" else "Execution failed."
            actionText.text = "Approval consumed. No other action is authorized."
        } catch (e: Exception) {
            statusText.text = "NOT EXECUTED: ${e.message}"
            actionText.text = "A new YES is required for any new action."
        } finally {
            demoRequest = null
        }
    }

    private fun denyAction() {
        PermissionGate.deny()
        ApprovalNotifier.cancel(this)
        demoRequest = null
        statusText.text = "DENIED — no action was performed."
        actionText.text = "No pending action."
    }
}
