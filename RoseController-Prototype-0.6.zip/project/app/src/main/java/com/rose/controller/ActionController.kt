package com.rose.controller

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper

class ActionController(private val service: ScreenObserverService) {
    fun execute(request: ActionRequest, currentSnapshot: ScreenSnapshot): Boolean {
        require(request.status == ApprovalStatus.APPROVED) { "Action requires explicit approval." }
        require(request.screenStateId == currentSnapshot.id) { "Screen changed before execution." }

        val result = when (request.type) {
            ActionType.TAP -> {
                val bounds = request.targetBounds
                requireNotNull(bounds) { "A target location is required." }
                performTap(PointF(bounds.centerX().toFloat(), bounds.centerY().toFloat()))
            }
            ActionType.BACK -> service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            ActionType.HOME -> service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            else -> false
        }

        request.status = if (result) ApprovalStatus.EXECUTED else ApprovalStatus.FAILED
        return result
    }

    private fun performTap(point: PointF): Boolean {
        val path = Path().apply { moveTo(point.x, point.y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return service.dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }
}
