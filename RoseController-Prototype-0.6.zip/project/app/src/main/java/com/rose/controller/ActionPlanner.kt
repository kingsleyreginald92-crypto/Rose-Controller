package com.rose.controller

import android.graphics.Rect

object ActionPlanner {
    fun proposeTap(label: String, snapshot: ScreenSnapshot = ScreenObserverService.currentSnapshot): ActionRequest? {
        val node = snapshot.nodes.firstOrNull { candidate ->
            candidate.enabled && candidate.clickable && (
                candidate.text.equals(label, ignoreCase = true) ||
                candidate.contentDescription.equals(label, ignoreCase = true)
            )
        } ?: return null

        return makeTapRequest(label, node, snapshot)
    }

    /**
     * Prototype instruction understanding: match the user's requested words
     * against the labels/content descriptions exposed by AccessibilityService.
     * This does not use an external AI model yet.
     */
    fun proposeTapFromInstruction(
        instruction: String,
        snapshot: ScreenSnapshot = ScreenObserverService.currentSnapshot
    ): ActionRequest? {
        val query = normalize(instruction)
        if (query.isBlank()) return null

        val candidates = snapshot.nodes.filter { it.enabled && it.clickable }
        if (candidates.isEmpty()) return null

        // 1) Exact label match.
        candidates.firstOrNull { node ->
            val label = node.text ?: node.contentDescription ?: return@firstOrNull false
            normalize(label) == query
        }?.let { return makeTapRequest(it.text ?: it.contentDescription ?: query, it, snapshot) }

        // 2) Common command wording: "open settings", "tap settings", etc.
        val targetPhrase = query
            .replace(Regex("^(please\\s+)?(open|tap|click|press|select|choose|go\\s+to)\\s+"), "")
            .trim()

        // 3) Prefer a label that contains the requested target phrase.
        candidates.firstOrNull { node ->
            val label = node.text ?: node.contentDescription ?: return@firstOrNull false
            val normalizedLabel = normalize(label)
            targetPhrase.isNotBlank() && (
                normalizedLabel == targetPhrase ||
                normalizedLabel.contains(targetPhrase) ||
                targetPhrase.contains(normalizedLabel)
            )
        }?.let { return makeTapRequest(it.text ?: it.contentDescription ?: targetPhrase, it, snapshot) }

        // 4) Token overlap for natural phrasing such as "please open the settings app".
        val queryTokens = targetPhrase.split(" ").filter { it.length > 2 }.toSet()
        if (queryTokens.isEmpty()) return null

        val best = candidates.mapNotNull { node ->
            val label = node.text ?: node.contentDescription ?: return@mapNotNull null
            val labelTokens = normalize(label).split(" ").filter { it.length > 2 }.toSet()
            val score = queryTokens.intersect(labelTokens).size
            if (score > 0) score to node else null
        }.maxByOrNull { it.first }?.second

        return best?.let { makeTapRequest(it.text ?: it.contentDescription ?: targetPhrase, it, snapshot) }
    }

    private fun normalize(value: String): String =
        value.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim().replace(Regex("\\s+"), " ")

    private fun makeTapRequest(label: String, node: ScreenNode, snapshot: ScreenSnapshot): ActionRequest {
        return ActionRequest(
            id = "action_${System.currentTimeMillis()}",
            type = ActionType.TAP,
            target = label,
            explanation = "Tap \"$label\" on the current screen.",
            screenStateId = snapshot.id,
            targetText = node.text,
            targetContentDescription = node.contentDescription,
            targetBounds = Rect(node.bounds)
        )
    }
}
