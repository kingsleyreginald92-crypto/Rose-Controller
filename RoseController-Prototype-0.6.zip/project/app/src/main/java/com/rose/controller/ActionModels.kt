package com.rose.controller

import android.graphics.Rect

enum class ActionType { TAP, TYPE, SWIPE, BACK, HOME }
enum class ApprovalStatus { PENDING, APPROVED, DENIED, EXECUTED, FAILED, EXPIRED }

data class ScreenNode(
    val text: String?,
    val contentDescription: String?,
    val className: String?,
    val clickable: Boolean,
    val enabled: Boolean,
    val bounds: Rect
)

data class ScreenSnapshot(
    val id: String,
    val packageName: String?,
    val nodes: List<ScreenNode>
)

data class ActionRequest(
    val id: String,
    val type: ActionType,
    val target: String,
    val explanation: String,
    val screenStateId: String,
    val targetText: String? = null,
    val targetContentDescription: String? = null,
    val targetBounds: Rect? = null,
    var status: ApprovalStatus = ApprovalStatus.PENDING
)
