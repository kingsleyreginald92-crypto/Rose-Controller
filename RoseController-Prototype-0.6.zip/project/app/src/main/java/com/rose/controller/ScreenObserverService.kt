package com.rose.controller

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.security.MessageDigest

class ScreenObserverService : AccessibilityService() {
    companion object {
        var instance: ScreenObserverService? = null
            private set

        @Volatile
        var currentSnapshot: ScreenSnapshot = ScreenSnapshot("unknown", null, emptyList())
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshSnapshot()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        refreshSnapshot()
    }

    override fun onInterrupt() = Unit

    fun refreshSnapshot(): ScreenSnapshot {
        val root = rootInActiveWindow
        if (root == null) {
            currentSnapshot = ScreenSnapshot("no_window", null, emptyList())
            return currentSnapshot
        }

        val nodes = mutableListOf<ScreenNode>()
        collectNodes(root, nodes)
        val packageName = root.packageName?.toString()
        val id = stableId(packageName, nodes)
        currentSnapshot = ScreenSnapshot(id, packageName, nodes)
        return currentSnapshot
    }

    private fun collectNodes(node: AccessibilityNodeInfo, out: MutableList<ScreenNode>) {
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        val description = node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }

        if ((text != null || description != null) && bounds.width() > 0 && bounds.height() > 0) {
            out += ScreenNode(
                text = text,
                contentDescription = description,
                className = node.className?.toString(),
                clickable = node.isClickable,
                enabled = node.isEnabled,
                bounds = Rect(bounds)
            )
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectNodes(child, out)
                child.recycle()
            }
        }
    }

    private fun stableId(packageName: String?, nodes: List<ScreenNode>): String {
        val canonical = buildString {
            append(packageName).append('|')
            nodes.forEach { n ->
                append(n.text).append('|')
                append(n.contentDescription).append('|')
                append(n.className).append('|')
                append(n.clickable).append('|')
                append(n.enabled).append('|')
                append(n.bounds.flattenToString()).append(';')
            }
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}
