package com.rose.controller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ApprovalReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val service = ScreenObserverService.instance ?: return
        val pending = PermissionGate.pending() ?: return

        when (intent.action) {
            ApprovalNotifier.ACTION_DENY -> {
                PermissionGate.deny()
                ApprovalNotifier.cancel(context)
            }
            ApprovalNotifier.ACTION_APPROVE -> {
                try {
                    val snapshot = service.refreshSnapshot()
                    val approved = PermissionGate.approve(snapshot)
                    ActionController(service).execute(approved, snapshot)
                } catch (_: Exception) {
                    // A changed screen or invalid request must never execute.
                    PermissionGate.deny()
                } finally {
                    ApprovalNotifier.cancel(context)
                }
            }
        }
    }
}
