package com.rose.controller

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object ApprovalNotifier {
    const val ACTION_APPROVE = "com.rose.controller.APPROVE"
    const val ACTION_DENY = "com.rose.controller.DENY"
    private const val CHANNEL_ID = "rose_approval"
    private const val NOTIFICATION_ID = 1001

    fun ensureChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Rose action approvals",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows one-action approval requests from Rose Controller."
            }
        )
    }

    fun show(context: Context, request: ActionRequest) {
        ensureChannel(context)
        val manager = context.getSystemService(NotificationManager::class.java)

        val approve = PendingIntent.getBroadcast(
            context,
            1,
            Intent(context, ApprovalReceiver::class.java).setAction(ACTION_APPROVE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val deny = PendingIntent.getBroadcast(
            context,
            2,
            Intent(context, ApprovalReceiver::class.java).setAction(ACTION_DENY),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Rose wants permission")
            .setContentText(request.explanation)
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "Rose wants to perform exactly this action:\n${request.explanation}\n\nApprove only this one action?"
            ))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(0, "APPROVE", approve)
            .addAction(0, "DENY", deny)
            .build()

        manager.notify(NOTIFICATION_ID, notification)
    }

    fun cancel(context: Context) {
        context.getSystemService(NotificationManager::class.java).cancel(NOTIFICATION_ID)
    }
}
